from boto3.dynamodb.conditions import Key, Attr
import boto3
from ast import literal_eval
import csv

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0;Win64;x64) AppleWebKit/537.36(KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'}  # header 변경
dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-2')
table = dynamodb.create_table(
    TableName='analyzed_wine_data',
    KeySchema=[{
        'AttributeName': 'id',
        'KeyType': 'HASH'
    }],
    AttributeDefinitions=[
        {
            'AttributeName': 'keywords',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'tf',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'similarity',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'similarWines',
            'AttributeType': 'S'
        }],
        ProvisionedThroughput={

        'ReadCapacityUnits': 10,

        'WriteCapacityUnits': 10

        }
)
table.meta.client.get_waiter('table_exists').wait(TableName='analyzed_wine_data')


print("table status:",table.table_status)