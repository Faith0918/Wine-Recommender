from boto3.dynamodb.conditions import Key, Attr
import boto3
from ast import literal_eval
import csv
class DBWriter:
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0;Win64;x64) AppleWebKit/537.36(KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'}  # header 변경
    dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-2')
    table = dynamodb.Table('wine_similarity')
    csv_data = []

    with open('wineid.csv', 'r', encoding='utf-8') as file:
        # csv_data = []
        for line in file.readlines():
            csv_data.append(line.split(','))

    # def __init__(self):
        # print("writer 생성")

    def write(self,id, tf, similarity, similar_wines):
        response = self.table.put_item(
            Item={
                'id': id,

                'tf': tf,
                'similarity':similarity,
                'similarWines':similar_wines

            }
        )