import keywordExtractor.reviewReader
import keywordExtractor.emojiRemover
import keywordExtractor.stringTranslator
import keywordExtractor.rakeKeywordManager
import keywordExtractor.frequencyCounter
import keywordExtractor.similarityCalculator
import keywordExtractor.dbWriter
import time
import json

class Core():
    reviewReader = keywordExtractor.reviewReader.ReviewReader()
    emojiRemover = keywordExtractor.emojiRemover.EmojiRemover()
    stringTranslator = keywordExtractor.stringTranslator.StringTranslator()
    rakeKeywordManager = keywordExtractor.rakeKeywordManager.RakeKeywordManager()
    frequencyCounter = keywordExtractor.frequencyCounter.FrequencyCounter()
    similarityCalculator = keywordExtractor.similarityCalculator.SimilarityCalculator()
    dbWriter = keywordExtractor.dbWriter.DBWriter()

core = Core()
w = input("와인 입력 : ")
c = input("상황 입력 : ")
a = core.reviewReader.getWineName1(1144172)
b = core.reviewReader.getWineName1(17366)
c = core.reviewReader.getWineName1(1146914)
d = core.reviewReader.getWineName1(2058935)
e = core.reviewReader.getWineName1(4511)

print(a)
print(b)
print(c)
print(d)
print(e)
# for wineIndex in range(1,225):
#
#     a = core.reviewReader.getWineReviews(wineIndex)
#     b = core.emojiRemover.getEmojilessList(a)
#     englishReviewString = ""
#     reviewString = ""
#     for num in range(0, len(b)):
#         # if  core.stringTranslator.getLanguage(b[num])!="" and str(core.stringTranslator.getLanguage(b[num]).lang)=='en':
#         #     print("english")
#             reviewString = reviewString + b[num]
#         # time.sleep(0.2)
#     # englishReviewString = core.stringTranslator.removeNonEnglish(reviewString)
#     englishReviewString = reviewString
#     core.rakeKeywordManager.setReviews(core.reviewReader.getId(wineIndex),englishReviewString)
#     # print(englishReviewString)
#     # keywords = core.rakeKeywordManager.getKeywords(englishReviewString)
#     # selectedKeywordsList = core.rakeKeywordManager.selectKeywords(keywords)
#     # core.reviewReader.setKeywords(wineIndex, selectedKeywordsList)
#     # core.rakeKeywordManager.setKeywords(core.reviewReader.getId(wineIndex),englishReviewString)
#     # print(core.reviewReader.getId(wineIndex),core.rakeKeywordManager.reviews.get(core.reviewReader.getId(wineIndex)))
#     # print(keywords)
#     # print(selectedKeywordsList)
#     # core.rakeKeywordManager.keyVectorSet.update(selectedKeywordsList)
#
# # for wineIndex in range(1,225):
#     # core.frequencyCounter.countNSetFrequency(core.reviewReader.getId(wineIndex),core.rakeKeywordManager.reviews[core.reviewReader.getId(wineIndex)], core.rakeKeywordManager.keyVectorSet)
#
# for wineIndex in range(1,225):
#     core.frequencyCounter.countNSetFrequency(core.reviewReader.getId(wineIndex), core.rakeKeywordManager.reviews[core.reviewReader.getId(wineIndex)], core.frequencyCounter.finalKeywords)
# #     core.dB에저장(core.reviewReader.getId(wineIndex), core.frequencyCounter.getFrequencyVector(core.reviewReader.getId(wineIndex)))
#
# for wineIndexI in range(1,2):
#     # similarityDictionary = {}
#     similarityVector = {}
#     for wineIndexJ in range(1, 225):
#         similarity = core.similarityCalculator.calculateSimilarity(core.frequencyCounter.getFrequencyVector(core.reviewReader.getId(wineIndexI)), core.frequencyCounter.getFrequencyVector(core.reviewReader.getId(wineIndexJ)))
#         similarityVector[core.reviewReader.getId(wineIndexJ)] = similarity
#     core.similarityCalculator.setSimilarity(core.reviewReader.getId(wineIndexI), similarityVector)
#     core.similarityCalculator.setSimilarWines(core.reviewReader.getId(wineIndexI))
#     # core.dbWriter.write(core.reviewReader.getId(wineIndexI),json.dumps(core.frequencyCounter.getFrequencyVector(core.reviewReader.getId(wineIndexI))),json.dumps(core.similarityCalculator.similarityVectors[core.reviewReader.getId(wineIndexI)]),json.dumps(core.similarityCalculator.similarWinesVectors[core.reviewReader.getId(wineIndexI)]))
#     print("similarity : id", core.reviewReader.getId(wineIndexI), similarityVector)


# print(len(core.frequencyCounter.finalKeywords))
# print(core.frequencyCounter.finalKeywords)
