from rake_nltk import Rake


class RakeKeywordManager:
    r = Rake()
    reviews = {}
    keyVectorSet = set()


    def getKeywords(self, string):
        self.r.extract_keywords_from_text(string)
        return self.r.get_ranked_phrases()

    def selectKeywords(selfself, keywordsList):
        selectedKeywordsList = []
        for keyword in keywordsList:
            words = keyword.split()
            if len(words)==1 and len(keyword)>3:
                selectedKeywordsList.append(keyword)
        return selectedKeywordsList

    def setReviews(self, id, review):
        self.reviews[id] = review

    def setTFVector(self,id):
        # review = self.reviews.get(id)
        # tfVector = []
        # for key in self.keyVectorSet:
            print(self.r.get_word_frequency_distribution())
        # self.r.frequency_dist()
    # def getKeywords(self, id):
    #     return self.keywords[id]
    # def buildFrequency