import operator
class SimilarityCalculator:
    similarityVectors = {}
    similarWinesVectors={}
    def calculateSimilarity(self, tfVector1, tfVector2):

        sum1 = 0
        sum2 = 0
        for word in tfVector1.keys():
            sum1 += tfVector1[word]**2
            sum2 += tfVector2[word]**2

        denominator = (sum1*sum2)**0.5

        nominator = 0
        for word in tfVector1.keys():
            nominator += tfVector1[word]*tfVector2[word]
        return nominator/denominator

    def setSimilarity(self, id, similarityVector):
        self.similarityVectors[id] = dict(sorted(similarityVector.items(), key=operator.itemgetter(1), reverse=True))
    def setSimilarWines(self, id):
        self.similarWinesVectors[id] = dict(sorted(self.similarityVectors[id].items(), key=operator.itemgetter(1), reverse=True)[:30])