from googletrans import Translator
import json
import nltk

class StringTranslator:
    translator = Translator()
    def getLanguage(self,string):
        try:
            return self.translator.detect(string)
        except json.decoder.JSONDecodeError:
            return ""
    def removeNonEnglish(self, string):
        words = set(nltk.corpus.words.words())
        str = " "
        str.join(w for w in nltk.wordpunct_tokenize(string)\
         if w.lower() in words or not w.isalpha())
        return str