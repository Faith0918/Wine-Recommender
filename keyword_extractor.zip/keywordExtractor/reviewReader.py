from boto3.dynamodb.conditions import Key, Attr
import boto3
from ast import literal_eval
import csv

class ReviewReader:
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0;Win64;x64) AppleWebKit/537.36(KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'}  # header 변경
    dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-2')
    table = dynamodb.Table('wine_review')
    table2 = dynamodb.Table('wine_similarity')
    csv_data = []

    with open('wineid.csv', 'r', encoding='utf-8') as file:
        # csv_data = []
        for line in file.readlines():
            csv_data.append(line.split(','))
    # def __init__(self):
        # print("reader 생성")

    def getId(self, wineIndex):
        x = 0
        id = self.csv_data[wineIndex][0]
        return eval(id)



    def getWineReviews(self, wineIndex):
        x = 0
        eqid = self.csv_data[wineIndex][0]
        response = self.table.query(

            KeyConditionExpression=Key('id').eq(eval(eqid))
        )
        item = response['Items']
        id1 = item[x]['id']
        review = item[x]['review']

        # print("id:", id1)
        # print(review)
        return self.makeReviewList(review)

    def getWineName1(self, idx):
        x = 0

        response = self.table.query(

            KeyConditionExpression=Key('id').eq(idx)
        )
        item = response['Items']
        id1 = item[x]['id']
        name = item[x]['name']
        return name



    def makeReviewList(self, rawReview):
        reviewList = []
        dictionary = literal_eval(rawReview)
        for num in range(0,len(dictionary)-1):
            reviewList.append(dictionary[num]['note'])

        return reviewList

    def updateTF(self, wineIndex,tf):
        x=0
        eqid = self.csv_data[wineIndex][0]
        # response = self.table.query(
        #
        #     KeyConditionExpression=Key('id').eq(eval(eqid))
        # )
        self.table.update_item(
            Key={
                'id' : eval(eqid)
            },

            UpdateExpression='ADD tf = :val',

            ExpressionAttributeValues={
                ':val': str(tf)
            }
        )

